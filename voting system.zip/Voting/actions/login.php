<?php
include('connect.php');

$student_name=$_POST['student_name'];
$student_Id=$_POST['student_Id'];
$password=$_POST['password'];


$sql="Select * from userdata where student_name='$student_name' and student_Id='$student_Id' and password='$password'";

$result=mysqli_query($con,$sql);
if(mysqli_num_rows($result)>0){
    $sql="select student_name,votes,student_Id,id from userdata where status='1'";
    $resultstatus=mysqli_query($con,$sql);
    if (mysqli_num_rows($resultstatus)>0){
$status=mysqli_fetch_all($resultstatus,MYSQLI_ASSOC);
$_SESSION['status']=$status;

    }
$data=mysqli_fetch_array($result);
$_SESSION['id']=$data['id'];
$_SESSION['student_name']=$data['student_name'];
$_SESSION['data']=$data;

echo '<script>
alert("Invalid credentials");
window.location="../partials/dashboard.php";
</script>';
}else{
echo '<script>
alert("Invalid credentials");
window.location="../";
</script>';
}

?>