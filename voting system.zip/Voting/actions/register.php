<?php
// Assuming you have a database connection established

// Function to register a new user
function registerUser($student_name, $student_Id, $password, $cpassword, ) {
    // Check if the user already exists
    $existingUserQuery = "SELECT * FROM userdata WHERE student_Id = '$student_Id'";
    $conn = mysqli_connect('localhost', 'sydney@', 'sydneymusalia', 'voting_system');
$existingUserQuery = "SELECT * FROM userdata";
$existingUserResult = mysqli_query($conn, $existingUserQuery);

    

    if (mysqli_num_rows($existingUserResult) > 0) {
        return "User already exists";
    }

    // Insert new user into the database
    $insertUserQuery = "INSERT INTO userdata (student_name, student_Id, password, cpassword) VALUES ('$student_name', '$student_Id', '$password', '$cpassword')";
    $insertUserResult = mysqli_query($conn, $insertUserQuery);

    if ($insertUserResult) {
        return "Registration successful";
    } else {
        return "Registration failed";
    }
}

// Handle the registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = $_POST['student_name'];
    $student_Id = $_POST['student_Id'];
    $password = $_POST['password'];
    $cpassword = $_POST['password'];

    // Perform input validation and sanitation

    // Call the registerUser function
    $registrationResult = registerUser($student_name, $student_Id, $password, $cpassword);

    // Display registration result
    echo $registrationResult;
}
?>
