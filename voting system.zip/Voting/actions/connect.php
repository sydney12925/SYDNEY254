<?php

$con=mysqli_connect("localhost","sydney@","sydneymusalia","voting_system");
if($con){
    echo"connection successful";
}else{
die(mysqli_error($conn));
}
?>