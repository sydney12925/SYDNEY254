<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:../');
}
$data = $_SESSION['data'];
if ($_SESSION["status"] == 1) {
    $status = '<b class="text-success">Voted</b>';
} else {
    $status = '<b class="text-danger">Not Voted</b>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting system dashboard</title>
    <!-- Bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- CSS file -->
    <link rel="stylesheet" href="../style.css">
</head>

<body class="bg-dark text-light">
    <div class="container p-3">
        <a href="logout.php"><button class="btn btn-dark text-light px-4">Logout</button></a>
        <h1 class="text-info text-center my-3">Voting system</h1>
        <div class="row my-5">
            <div class="col-md-5"></div>
            <!-- user profile -->
            <div class="col-md-7">
                <strong class="text-light">Student name:</strong>
                <?php echo isset($data['student_name']) ? $data['student_name'] : ''; ?><br><br>
                <strong class="text-light">Student Id:</strong>
                <?php echo isset($data['student_id']) ? $data['student_id'] : ''; ?><br><br>
                <strong class="text-light">Status:</strong>
                <?php echo $status; ?><br><br>
            </div>
        </div>
    </div>
</body>

</html>

