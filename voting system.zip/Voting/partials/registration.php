<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting system -Registration page</title>
    <!-- Bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> 
</head>
<body class="bg-dark">
    <h1 class="text-center text-info p-3">Voting system</h1>
<div class="bg-info py-4">
<h2 class="text-center">Register account</h2>
<div class="container text-center">
    <form action="../actions/register.php" method="POST">
        <div class="mb-3">
            <input type="text" class="form-control w-50 m-auto" placeholder="Enter student name" required="required" name="student_name">
        </div>
        <div class="mb-3">
            <input type="text" class="form-control w-50 m-auto" placeholder="Enter Student Id" required="required" name="student_Id">
        </div>
        <div class="mb-3">
            <input type="text" class="form-control w-50 m-auto" placeholder="Enter password" required="required" name="password">
        </div>
        <div class="mb-3">
            <input type="text" class="form-control w-50 m-auto" placeholder="Confirm password" required="required" name="cpassword">
        </div>
        <button type="submit" class="btn btn-dark my-4">Register</button>
        <p>Already have an account ? <a href="../" class="text-white">Login here</a></p>

    </form>
</div>
</div>

</body>
</html>